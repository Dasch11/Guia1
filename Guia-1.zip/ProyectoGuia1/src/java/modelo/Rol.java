/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author diego
 */
@XmlRootElement
public class Rol implements Serializable {
    
    private int id;
    private String nombre;
    
    private List<Usuario> usuarios = new ArrayList<>();

    public Rol() {
        this.usuarios = new ArrayList<>();
    }

    public Rol(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
        this.usuarios = new ArrayList<>();
    }

    Rol(Rol rol) {
       this.id = rol.getId();
        this.nombre = rol.getNombre();
        this.usuarios = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<Usuario> getUsuarios() {
        return usuarios;
    }

    public void setUsuarios(List<Usuario> usuarios) {
        this.usuarios = usuarios;
    }
    
    
    
    
}
