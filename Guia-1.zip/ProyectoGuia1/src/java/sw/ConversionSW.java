/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sw;

import java.util.ArrayList;
import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import modelo.*;

/**
 *
 * @author diego
 */
@WebService(serviceName = "ConversionSW")
public class ConversionSW {

    private static final List<Persona> personas = new ArrayList<>();
    private static final List<Usuario> usuarios = new ArrayList<>();
    private static final List<Rol> roles = new ArrayList<>();

    static {
        cargarDatos(personas, usuarios, roles);
    }

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "euroAdolar")
    public double euroAdolar(@WebParam(name = "euros") double euros) {
        //TODO write your implementation code here:
        return euros * 115;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "obtenerPersonasPorUsuario")
    public List<Persona> obtenerPersonasPorUsuario(
            @WebParam(name = "nombreUsuario") String nombreUsuario,
            @WebParam(name = "contrasena") String contrasena) {

        List<Persona> personasEncontradas = new ArrayList<>();
        Usuario usuarioAutenticado = null;

        // Buscar usuario con las credenciales correctas
        for (Usuario u : usuarios) {
            if (u.getNombreUsuario().equals(nombreUsuario)
                    && u.getContrasena().equals(contrasena)) {
                usuarioAutenticado = u;
                break;
            }
        }

        // Si se encontró el usuario, buscar las personas asociadas
        if (usuarioAutenticado != null) {
            for (Persona p : personas) {
                if (p.getUsuario().getId() == usuarioAutenticado.getId()) {
                    personasEncontradas.add(p);
                }
            }
        }

        return personasEncontradas;
    }

    @WebMethod(operationName = "obtenerUsuariosConRoles")
public List<Usuario> obtenerUsuariosConRoles() {
    // Devuelve la lista de usuarios cargada al inicio
    return usuarios;
}


    private static void cargarDatos(
            List<Persona> personas,
            List<Usuario> usuarios,
            List<Rol> roles) {

        // Crear roles
        Rol r1 = new Rol(1, "Administrador");
        Rol r2 = new Rol(2, "Usuario");
        Rol r3 = new Rol(3, "Invitador");
        roles.add(r1);
        roles.add(r2);
        roles.add(r3);

        // Crear usuarios (cada uno con su rol correcto)
        Usuario u1 = new Usuario(1, "Admin", "admin1", r1);
        Usuario u2 = new Usuario(2, "Diegos", "D1234", r2);
        Usuario u3 = new Usuario(3, "Maria", "M1234", r3);
        usuarios.add(u1);
        usuarios.add(u2);
        usuarios.add(u3);

        // Crear personas asociadas a cada usuario
        Persona p1 = new Persona(1, "Diego", "Suqui", u2);
        Persona p2 = new Persona(2, "Maria", "Chamba", u3);
        Persona p3 = new Persona(3, "Admin", "istrador", u1);
        personas.add(p1);
        personas.add(p2);
        personas.add(p3);

        // Agregar usuarios a sus roles (coherente con la relación definida en Usuario)
        r1.getUsuarios().add(u1);
        r2.getUsuarios().add(u2);
        r3.getUsuarios().add(u3);
    }

}
