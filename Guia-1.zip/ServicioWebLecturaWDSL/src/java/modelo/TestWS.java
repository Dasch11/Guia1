/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import sw.ConversionSW;
import sw.ConversionSW_Service;
import sw.*;

/**
 *
 * @author diego
 */
public class TestWS {

    public static void main(String[] args) {

        ConversionSW_Service service = new ConversionSW_Service();
        ConversionSW cliente = service.getConversionSWPort();

        System.out.println("Resultado 1:" + cliente.hello("Diego"));
        System.out.println("Resultado 1:" + cliente.euroAdolar(100));

        System.out.println("\n**************************");
        System.out.println("        LOGIN          "     );
        System.out.println(" ***************************");

        // Solicitar credenciales con Scanner
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese nombre de usuario: ");
        String nombreUsuario = scanner.nextLine();

        System.out.print("Ingrese contraseña: ");
        String contrasena = scanner.nextLine();

        // Hacer el login y recibir la lista de personas
        List<Persona> personas = cliente.obtenerPersonasPorUsuario(nombreUsuario, contrasena);

        System.out.println("\n**************************");

        // Verificar si se encontraron personas
        if (personas == null || personas.isEmpty()) {
            System.out.println(" Credenciales incorrectas o no hay personas asociadas.");
        } else {
            System.out.println(" Login exitoso!");
            System.out.println("****************************");

            // Mostrar saludo para cada persona
            for (Persona persona : personas) {
                System.out.println("Hola " + persona.getNombre() + " " + persona.getApellido());
            }

            System.out.println("\n************ HASHMAP ***********");
            System.out.println("    USUARIOS Y ROLES DEL SISTEMA");
            System.out.println("*****************************************");

            // Obtener usuarios con roles y mostrar en HashMap
            List<Usuario> listaUsuarios = cliente.obtenerUsuariosConRoles();
            Map<String, String> usuariosRoles = new HashMap<>();

            // Llenar el HashMap con nombreUsuario -> nombreRol
            for (Usuario usuario : listaUsuarios) {
                usuariosRoles.put(usuario.getNombreUsuario(), usuario.getRol().getNombre());
            }

            // Mostrar el HashMap en consola
            for (Map.Entry<String, String> entry : usuariosRoles.entrySet()) {
                System.out.println("Usuario: " + entry.getKey() + " | Rol: " + entry.getValue());
            }

            System.out.println("***************************************");
            System.out.println("Total de usuarios: " + usuariosRoles.size());
            System.out.println("****************************************");
        }

        scanner.close();
    }
}
